실행시 헤더파일 명만 바꾸어 주면 됩니다!

ex) 
array형태로 실행시킬때 : #include "Stack_Array.h"
linked list 형태로 실행시킬때 : #include "Stack_Link.h"