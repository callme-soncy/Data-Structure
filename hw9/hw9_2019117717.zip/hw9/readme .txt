	1. list.h + search.c  실행후 testfile명 입력
		
		hash의 중첩을 막기 위한 방법으로 linkedlist를 활용하였음
		(10으로 나눈 나머지 값에 따라 list의 노드로 저장)

	2. sort.c   실행후 testfile명 입력


		<<testfile>>

 		- test.txt	    200개의 랜덤한 정수 목록
 		- test1.txt   100개의 랜덤한 정수 목록
 		- test2.txt   350개의 랜덤한 정수 목록
 		- test3.txt   10개의 랜덤한 정수 목록